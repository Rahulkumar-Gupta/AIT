var calculator = require('./first.js');
var a=10,b=5;
console.log("Addition :"+calculator.add(a,b));
console.log("Substraction :"+calculator.sub(a,b));
console.log("Multiplication :"+calculator.multy(a,b));
console.log("Division :"+calculator.div(a,b));